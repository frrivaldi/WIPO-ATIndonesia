# DISSA 2 — PLC Mixer Simulator DEV

> **Status: DEV / SIM only.** Repositori ini disiapkan untuk menjalankan flow **Config + Simulator** yang telah divalidasi secara lokal. Flow aktual dari laptop belum disertakan dalam template ini.

## Cakupan

- **Hanya** Simulator PLC Mixer DISSA 2 dan konfigurasi Master Tag G2 yang dibutuhkan simulator.
- 56 tag aktif (22 proses, 11 status, 23 correction); data contoh sintetis, **bukan** pembacaan PLC asli.
- Pengiriman ke **InfluxDB Cloud** bucket `mixer_dev`, measurement `mixer_sample` dan `mixer_batch` (setelah credentials diisi ulang secara lokal).
- Visualisasi melalui **Grafana Cloud** yang sudah dibagikan pemiliknya.
- **Tidak ada** koneksi PLC fisik, Ind MC Read aktif, 60-minute REAL pilot, atau token yang disimpan di Git.

## Sebelum dijalankan

1. Lakukan ekspor flow **Config** dan **Simulator** dari Node-RED asli. Lihat [Panduan Transfer Flow](docs/TRANSFER_FLOW.md). Jangan salin flow Pilot/Acquisition ke repositori ini.
2. Hasilkan `flows.json` berisi dua tab tersebut beserta *config nodes* yang diperlukan. **Tidak ada** `flows.json` asli dalam starter package ini.
3. Pastikan tersedia Node.js yang kompatibel dengan Node-RED 5 (misalnya Node.js 24) dan jaringan untuk npm/InfluxDB Cloud.
4. Jalankan `npm install` di folder repositori.
5. Jalankan `START_SIMULATOR.cmd`. Editor biasanya tersedia di `http://127.0.0.1:1880` (jika port tidak dipakai instance lain).
6. Periksa node InfluxDB, masukkan endpoint/org/bucket dan credential **secara lokal**, lalu Deploy. Token tidak ada di repo.
7. Tes `LOAD CONFIG` dan jalankan simulator. Verifikasi query data aktual di InfluxDB dan panel Grafana; jangan menganggap berhasil hanya karena Node-RED started.

> **Catatan jaringan:** InfluxDB Cloud dan Grafana Cloud bukan server lokal di laptop. GitHub tidak meng-host Node-RED/InfluxDB. Laptop menjalankan Node-RED, sementara InfluxDB dan Grafana diakses via Internet yang disetujui.

## Menjalankan Node-RED

```cmd
cd /d C:\DISSA2_MONITORING\dissa2-mixer-simulator-dev
npm install
START_SIMULATOR.cmd
```

Jika Node-RED lama sudah berjalan di port 1880, hentikan instance lama dahulu untuk mencegah konflik. Jangan jalankan dua instance yang membaca/mengubah konfigurasi userDir yang sama.

## File yang tidak boleh di-push

`flows_cred.json`, `settings.js`, `.env`, token/API key, folder `node_modules`, log, file backup, dan data mesin nyata. Lihat `.gitignore`.

## Dokumen

- [Transfer flow yang benar-benar berjalan di laptop](docs/TRANSFER_FLOW.md)
- [Checklist DEV dan privasi](docs/DEV_CHECKLIST.md)

## Keadaan terkini

- [x] Template repo dan dokumentasi siap.
- [ ] `flows.json` **aktual** dari laptop ditambahkan, diperiksa, dan diverifikasi.
- [ ] Node-RED berjalan dari folder repo ini.
- [ ] InfluxDB `mixer_dev` dan Grafana diverifikasi dengan data SIM.
