@echo off
setlocal
cd /d "%~dp0"
if not exist "flows.json" (
  echo [ERROR] flows.json belum ada.
  echo Ekspor Config + Simulator yang sudah diuji di laptop terlebih dahulu.
  echo Baca docs\TRANSFER_FLOW.md
  pause
  exit /b 1
)
if not exist "node_modules\node-red\package.json" (
  echo [ERROR] Dependency Node-RED belum terinstal. Jalankan: npm install
  pause
  exit /b 1
)
REM SIM only: jangan pernah gunakan ini untuk PLC fisik.
set "DISSA2_MODE=SIM"
set "DISSA2_PILOT_MC_APPROVED=NO"
set "DISSA2_PILOT_CLOUD_APPROVED=NO"
call ".\node_modules\.bin\node-red.cmd" --userDir "%CD%" flows.json
endlocal
