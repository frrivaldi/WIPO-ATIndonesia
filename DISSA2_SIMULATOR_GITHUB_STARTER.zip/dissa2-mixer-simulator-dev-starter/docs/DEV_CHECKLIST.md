# Checklist handover Simulator DEV

- [ ] Repository GitHub dalam keadaan **Private**.
- [ ] Flow mencakup hanya `Config` dan `Simulator` serta dependencies yang dibutuhkan.
- [ ] Tidak ada node `Ind MC Read`/MC Write aktif dan tidak ada koneksi PLC fisik.
- [ ] Semua token, password, dan `flows_cred.json` dikecualikan dari Git.
- [ ] Node-RED berjalan dari folder repo menggunakan `START_SIMULATOR.cmd`.
- [ ] Master G2 menghasilkan 56 tag (22 proses, 11 status, 23 correction).
- [ ] Kedua measurement DEV `mixer_sample` dan `mixer_batch` muncul di InfluxDB Cloud `mixer_dev`.
- [ ] Data dikonfirmasi mempunyai `source=SIM`; tidak tercampur dengan data PLC fisik.
- [ ] Grafana Cloud datasource DEV dan dashboard yang telah dibagikan menampilkan data SIM.
- [ ] Teknisian tahu Node-RED berjalan di laptop dan InfluxDB/Grafana berjalan di Cloud.
- [ ] Tidak ada kredensial produksi atau informasi rahasia yang dipublikasikan.
