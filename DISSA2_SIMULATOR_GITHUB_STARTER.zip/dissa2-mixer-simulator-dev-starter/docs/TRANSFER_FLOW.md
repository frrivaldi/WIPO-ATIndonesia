# Transfer flow Config + Simulator dari Node-RED laptop

**Jangan mengambil `flows.json` lama dari repository Production.** Source of truth ialah canvas Node-RED laptop yang sudah berhasil menulis ke bucket `mixer_dev`.

## Rute aman (melalui editor Node-RED)

1. **Backup** `C:\DISSA2_MONITORING\nodered\flows.json` di laptop sebelum melakukan ekspor.
2. Buka editor Node-RED yang sudah berjalan (`http://127.0.0.1:1880`).
3. Di tab **Config**, buka menu (☰) → **Export** → pilih **Current Flow**, lalu simpan sebagai `config-export.json` **di luar repo**. Pastikan pemetaan G2 dibawa bila Simulator mengandalkannya.
4. Di tab **Simulator**, lakukan **Export → Current Flow** sebagai `simulator-export.json` **di luar repo**. Pastikan configuration nodes InfluxDB yang direferensikan termasuk/tersedia saat diimpor.
5. Di *userDir* Node-RED baru yang terpisah dari instalasi lama, **Import** kedua ekspor. Periksa setiap konfigurasi node InfluxDB; masukkan ulang credential secara lokal.
6. Hapus flow/tab lain yang tidak berkaitan. Pastikan hanya tab Config & Simulator, tanpa node MC Read/Write atau pilot REAL.
7. Deploy dan lakukan uji DEV. Setelah lolos, hentikan Node-RED baru, dan gunakan `flows.json` yang dihasilkannya sebagai `flows.json` di root repo.
8. **Sebelum `git add`**, buka `flows.json` dan tinjau semua URL, IP, token, password, API key, serta data sensitif. Jangan sertakan berkas `flows_cred.json`.

> Jika ragu bagaimana mengekspor dan menggabungkan dua tab tanpa kehilangan referensi, berhenti di langkah 4 dan berikan **hanya file ekspor flow** kepada asisten untuk diperiksa. Jangan mengunggah credential file atau token.

## Publikasi repo GitHub (setelah repo PRIVATE dibuat)

```cmd
cd /d C:\DISSA2_MONITORING\dissa2-mixer-simulator-dev
git init
git branch -M main
git add .gitignore README.md package.json START_SIMULATOR.cmd docs flows.json
git status
git commit -m "Initialize DISSA2 simulator-only Node-RED DEV"
git remote add origin https://github.com/frrivaldi/dissa2-mixer-simulator-dev.git
git push -u origin main
```

Periksa `git status` dan file staged sebelum commit. Jika `flows.json` belum valid, **jangan push** file placeholder maupun flow Production lama. Pada GitHub, jika sudah menginisialisasi repo dengan README, gunakan clone/pull alih-alih `git init` + push non-fast-forward.
